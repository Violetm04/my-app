const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));


app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
}));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'student_finance'
});

db.connect(err => {
  if (err) {
    console.error('DB connection error:', err);
    process.exit(1);
  }
  console.log('Connected to MySQL database');
});

// ---------------- Routes ----------------

// Home - Dashboard if logged in
app.get('/', (req, res) => {
  if (req.session.user) {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
  } else {
    res.redirect('/login.html');
  }
});

// Serve login, register, and dashboard pages
app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/register.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// Your custom routes first
app.get('/', (req, res) => {
  if (req.session.user) {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
  } else {
    res.redirect('/login.html');
  }
});

app.get('/dashboard.html', (req, res) => {
  if (req.session.user) {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
  } else {
    res.redirect('/login.html');
  }
});


// Register
app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const sql = 'INSERT INTO users (username, password) VALUES (?, ?)';
  db.query(sql, [username, hashedPassword], (err) => {
    if (err) return res.send('Username taken or error occurred');
    res.send('Registered. <a href="/login.html">Login</a>');
  });
});

// Login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (err || results.length === 0) return res.send('Invalid login');
    const user = results[0];
    const match = await bcrypt.compare(password, user.password);
    if (match) {
      req.session.user = user;
      res.redirect('/');
    } else {
      res.send('Invalid password');
    }
  });
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login.html');
  });
});

// Add Student
app.post('/add-student', (req, res) => {
  const { full_name, email, phone, registered_date } = req.body;
  const sql = 'INSERT INTO students (full_name, email, phone, registered_date) VALUES (?, ?, ?, ?)';
  db.query(sql, [full_name, email, phone, registered_date], (err) => {
    if (err) return res.status(500).send('Error adding student.');
    res.redirect('/students');
  });
});

// List Students
app.get('/students', (req, res) => {
  db.query('SELECT * FROM students', (err, results) => {
    if (err) return res.status(500).send('Error fetching students.');
    let html = `
  <h1>Students</h1>
  <form method="GET" action="/students/search">
    <input type="text" name="q" placeholder="Search by name or email" required />
    <button type="submit">Search</button>
  </form>
  <form method="POST" action="/add-student">
    <h2>Add Student</h2>
    <input name="full_name" placeholder="Full Name" required /><br>
    <input name="email" placeholder="Email" required /><br>
    <input name="phone" placeholder="Phone" required /><br>
    <input name="registered_date" type="date" required /><br>
    <button type="submit">Add</button>
  </form>
  <table border="1">
    <tr><th>Full Name</th><th>Email</th><th>Phone</th><th>Actions</th></tr>
`;
    results.forEach(s => {
      html += `
    <tr>
      <td>${s.full_name}</td>
      <td>${s.email}</td>
      <td>${s.phone}</td>
      <td>
        <a href="/students/edit/${s.student_id}">Edit</a> |
        <form action="/students/delete/${s.student_id}" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure?');">
          <button type="submit">Delete</button>
        </form> |
        <a href="/payments/${s.student_id}">Payments</a>
      </td>
    </tr>
  `;
    });
    html += '</table>';
    res.send(html);
  });
});

// Search Students
app.get('/students/search', (req, res) => {
  const query = `%${req.query.q}%`;
  db.query('SELECT * FROM students WHERE full_name LIKE ? OR email LIKE ?', [query, query], (err, results) => {
    if (err) return res.status(500).send('Search error.');
    let html = `<h1>Search Results</h1><a href="/students">Back</a><table border="1">
      <tr><th>Full Name</th><th>Email</th><th>Phone</th><th>Actions</th></tr>`;
    results.forEach(s => {
      html += `<tr>
        <td>${s.full_name}</td>
        <td>${s.email}</td>
        <td>${s.phone}</td>
        <td>
          <a href="/students/edit/${s.student_id}">Edit</a> |
          <form action="/students/delete/${s.student_id}" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure?');">
            <button type="submit">Delete</button>
          </form> |
          <a href="/payments/${s.student_id}">Payments</a>
        </td>
      </tr>`;
    });
    html += '</table>';
    res.send(html);
  });
});

// Edit Student Form
app.get('/students/edit/:student_id', (req, res) => {
  const id = req.params.student_id;
  db.query('SELECT * FROM students WHERE student_id = ?', [id], (err, results) => {
    if (err || results.length === 0) return res.send('Student not found');
    const s = results[0];
    const html = `
      <h1>Edit Student</h1>
      <form method="POST" action="/students/edit/${s.student_id}">
        <input name="full_name" value="${s.full_name}" required /><br>
        <input name="email" value="${s.email}" required /><br>
        <input name="phone" value="${s.phone}" required /><br>
        <button type="submit">Update</button>
      </form>
    `;
    res.send(html);
  });
});

// Update Student
app.post('/students/edit/:student_id', (req, res) => {
  const id = req.params.student_id;
  const { full_name, email, phone } = req.body;
  db.query('UPDATE students SET full_name=?, email=?, phone=? WHERE student_id=?', [full_name, email, phone, id], (err) => {
    if (err) return res.send('Update failed');
    res.redirect('/students');
  });
});

// Delete Student
app.post('/students/delete/:student_id', (req, res) => {
  db.query('DELETE FROM students WHERE student_id = ?', [req.params.student_id], (err) => {
    if (err) return res.send('Delete failed');
    res.redirect('/students');
  });
});

// Payment Form
app.get('/payments/:student_id', (req, res) => {
  const student_id = req.params.student_id;
  db.query('SELECT * FROM students WHERE student_id = ?', [student_id], (err, results) => {
    if (err || results.length === 0) return res.status(404).send('Student not found');
    const student = results[0];
    const html = `
      <h1>Record Payment for ${student.full_name}</h1>
      <form action="/payments/${student_id}" method="POST">
        <input type="number" name="amount" step="0.01" placeholder="Amount (R)" required><br>
        <input type="date" name="payment_date" required><br>
        <select name="payment_method" required>
          <option value="">Select Method</option>
          <option value="cash">Cash</option>
          <option value="scholarship">Scholarship</option>
          <option value="loan">Loan</option>
        </select><br>
        <button type="submit">Submit Payment</button>
      </form>
      <a href="/students">Back to Students</a>
    `;
    res.send(html);
  });
});

// Submit Payment
app.post('/payments/:student_id', (req, res) => {
  const student_id = req.params.student_id;
  const { amount, payment_date, payment_method } = req.body;
  const sql = 'INSERT INTO payments (student_id, amount, payment_date, payment_method) VALUES (?, ?, ?, ?)';
  db.query(sql, [student_id, amount, payment_date, payment_method], (err) => {
    if (err) return res.status(500).send('Error recording payment.');
    res.redirect(`/payments/${student_id}/history`);
  });
});

// Payment History
app.get('/payments/:student_id/history', (req, res) => {
  const student_id = req.params.student_id;
  db.query('SELECT * FROM students WHERE student_id = ?', [student_id], (err, students) => {
    if (err || students.length === 0) return res.status(404).send('Student not found');
    const student = students[0];
    db.query('SELECT * FROM payments WHERE student_id = ?', [student_id], (err, payments) => {
      if (err) return res.status(500).send('Error fetching payments.');
      let totalPaid = payments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
      let html = `<h1>Payments for ${student.full_name}</h1>
        <p>Total Paid: R${totalPaid.toFixed(2)}</p>
        <table border="1">
          <tr><th>Amount (R)</th><th>Date</th><th>Method</th></tr>`;
      payments.forEach(p => {
        html += `<tr><td>R${p.amount}</td><td>${p.payment_date}</td><td>${p.payment_method}</td></tr>`;
      });
      html += `</table><a href="/payments/${student_id}">Add Payment</a> | <a href="/students">Back</a>`;
      res.send(html);
    });
  });
});



// Route to show all unverified payments
app.get('/payments/unverified', (req, res) => {
  db.query(`SELECT payments.*, students.full_name 
            FROM payments 
            JOIN students ON payments.student_id = students.student_id 
            WHERE verified = false`, (err, results) => {
    if (err) return res.status(500).send('Error fetching unverified payments');

    let html = `<h1>Unverified Payments</h1>
    <table border="1">
      <tr><th>Student</th><th>Amount</th><th>Date</th><th>Method</th><th>Action</th></tr>`;

    results.forEach(p => {
      html += `
        <tr>
          <td>${p.full_name}</td>
          <td>R ${p.amount.toFixed(2)}</td>
          <td>${p.payment_date}</td>
          <td>${p.payment_method}</td>
          <td>
            <form method="POST" action="/payments/verify/${p.payment_id}">
              <button type="submit">Verify</button>
            </form>
          </td>
        </tr>`;
    });

    html += `</table><br><a href="/payments/verified">View Verified Payments</a>`;
    res.send(html);
  });
});

// Route to handle payment verification
app.post('/payments/verify/:id', (req, res) => {
  const id = req.params.id;
  db.query('UPDATE payments SET verified = true WHERE payment_id = ?', [id], (err) => {
    if (err) return res.status(500).send('Error verifying payment');
    res.redirect('/payments/unverified');
  });
});

// Route to show all verified payments
app.get('/payments/verified', (req, res) => {
  db.query(`SELECT payments.*, students.full_name 
            FROM payments 
            JOIN students ON payments.student_id = students.student_id 
            WHERE verified = true`, (err, results) => {
    if (err) return res.status(500).send('Error fetching verified payments');

    let html = `<h1>Verified Payments</h1>
    <table border="1">
      <tr><th>Student</th><th>Amount</th><th>Date</th><th>Method</th></tr>`;

    results.forEach(p => {
      html += `
        <tr>
          <td>${p.full_name}</td>
          <td>R ${p.amount.toFixed(2)}</td>
          <td>${p.payment_date}</td>
          <td>${p.payment_method}</td>
        </tr>`;
    });

    html += `</table><br><a href="/payments/unverified">Back to Unverified</a>`;
    res.send(html);
  });
});

// View all work-study assignments
app.get('/work-study', (req, res) => {
  db.query(`SELECT ws.*, s.full_name 
            FROM work_study_assignments ws
            JOIN students s ON ws.student_id = s.student_id`, 
    (err, results) => {
      if (err) return res.status(500).send('Error fetching work-study assignments.');
      let html = `<h1>Work-Study Assignments</h1>
      <a href="/work-study/new">Assign New</a><br><br>
      <table border="1"><tr>
      <th>Student</th><th>Position</th><th>Hours/Week</th><th>Hourly Rate</th><th>Credit</th></tr>`;
      results.forEach(r => {
        html += `<tr><td>${r.full_name}</td><td>${r.position_title}</td><td>${r.hours_per_week}</td><td>R${r.hourly_rate}</td><td>R${r.tuition_credit}</td></tr>`;
      });
      html += `</table>`;
      res.send(html);
    });
});

// Assign new work-study
app.get('/work-study/new', (req, res) => {
  db.query('SELECT * FROM students', (err, students) => {
    if (err) return res.status(500).send('Error fetching students.');
    let html = `<h1>New Work-Study Assignment</h1>
    <form method="POST" action="/work-study/new">
    <select name="student_id" required>
    <option value="">Select Student</option>`;
    students.forEach(s => html += `<option value="${s.student_id}">${s.full_name}</option>`);
    html += `</select><br>
    <input name="position_title" placeholder="Position Title" required><br>
    <input type="number" name="hours_per_week" placeholder="Hours/Week" required><br>
    <input type="number" step="0.01" name="hourly_rate" placeholder="Hourly Rate" required><br>
    <input type="number" step="0.01" name="tuition_credit" placeholder="Tuition Credit"><br>
    <input type="date" name="start_date" required><br>
    <input type="date" name="end_date"><br>
    <button type="submit">Save</button></form>`;
    res.send(html);
  });
});

app.post('/work-study/new', (req, res) => {
  const { student_id, position_title, hours_per_week, hourly_rate, tuition_credit, start_date, end_date } = req.body;
  db.query(`INSERT INTO work_study_assignments 
    (student_id, position_title, hours_per_week, hourly_rate, tuition_credit, start_date, end_date)
    VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [student_id, position_title, hours_per_week, hourly_rate, tuition_credit, start_date, end_date || null],
    (err) => {
      if (err) return res.status(500).send('Error saving work-study.');
      res.redirect('/work-study');
    });
});

// List donations
app.get('/donations', (req, res) => {
  db.query(`SELECT d.*, s.full_name 
            FROM donations d
            LEFT JOIN students s ON d.student_id = s.student_id`, 
    (err, results) => {
      if (err) return res.status(500).send('Error fetching donations.');
      let html = `<h1>Donations</h1>
      <a href="/donations/new">Make Donation</a>
      <table border="1"><tr><th>Donor</th><th>Email</th><th>Amount</th><th>Student</th><th>Message</th></tr>`;
      results.forEach(d => {
        html += `<tr><td>${d.donor_name}</td><td>${d.donor_email}</td><td>R${d.amount}</td><td>${d.full_name || 'General Fund'}</td><td>${d.message || ''}</td></tr>`;
      });
      html += `</table>`;
      res.send(html);
    });
});

// Donation form
app.get('/donations/new', (req, res) => {
  db.query('SELECT * FROM students', (err, students) => {
    if (err) return res.status(500).send('Error fetching students.');
    let html = `<h1>Make a Donation</h1>
    <form method="POST" action="/donations/new">
    <input name="donor_name" placeholder="Your Name" required><br>
    <input name="donor_email" placeholder="Your Email"><br>
    <input type="number" step="0.01" name="amount" placeholder="Amount" required><br>
    <select name="student_id">
      <option value="">General Fund</option>`;
    students.forEach(s => html += `<option value="${s.student_id}">${s.full_name}</option>`);
    html += `</select><br>
    <textarea name="message" placeholder="Message (optional)"></textarea><br>
    <input type="date" name="donation_date" required><br>
    <button type="submit">Donate</button></form>`;
    res.send(html);
  });
});

app.post('/donations/new', (req, res) => {
  const { donor_name, donor_email, amount, student_id, message, donation_date } = req.body;
  db.query(`INSERT INTO donations (donor_name, donor_email, amount, student_id, message, donation_date)
            VALUES (?, ?, ?, ?, ?, ?)`,
            [donor_name, donor_email, amount, student_id || null, message || null, donation_date],
            (err) => {
              if (err) return res.status(500).send('Error saving donation.');
              res.redirect('/donations');
            });
});

// View scholarships
app.get('/scholarships', (req, res) => {
  db.query('SELECT * FROM scholarship_listings', (err, results) => {
    if (err) return res.status(500).send('Error fetching scholarships.');
    let html = `<h1>Scholarships</h1>
    <a href="/scholarships/new">Add Scholarship</a>
    <table border="1"><tr><th>Title</th><th>Provider</th><th>Deadline</th><th>Actions</th></tr>`;
    results.forEach(s => {
      html += `<tr><td>${s.title}</td><td>${s.provider_name}</td><td>${s.application_deadline}</td>
      <td><a href="/scholarships/apply/${s.scholarship_id}">Apply</a></td></tr>`;
    });
    html += `</table>`;
    res.send(html);
  });
});

// Add scholarship
app.get('/scholarships/new', (req, res) => {
  res.send(`<h1>New Scholarship</h1>
  <form method="POST" action="/scholarships/new">
  <input name="title" placeholder="Title" required><br>
  <input name="provider_name" placeholder="Provider" required><br>
  <textarea name="description" placeholder="Description"></textarea><br>
  <textarea name="eligibility_criteria" placeholder="Eligibility Criteria"></textarea><br>
  <input type="date" name="application_deadline" required><br>
  <button type="submit">Save</button></form>`);
});

app.post('/scholarships/new', (req, res) => {
  const { title, provider_name, description, eligibility_criteria, application_deadline } = req.body;
  db.query(`INSERT INTO scholarship_listings (title, provider_name, description, eligibility_criteria, application_deadline)
            VALUES (?, ?, ?, ?, ?)`,
            [title, provider_name, description, eligibility_criteria, application_deadline],
            (err) => {
              if (err) return res.status(500).send('Error adding scholarship.');
              res.redirect('/scholarships');
            });
});

// Apply for scholarship
app.get('/scholarships/apply/:id', (req, res) => {
  const scholarship_id = req.params.id;
  db.query('SELECT * FROM students', (err, students) => {
    if (err) return res.status(500).send('Error fetching students.');
    let html = `<h1>Apply for Scholarship</h1>
    <form method="POST" action="/scholarships/apply/${scholarship_id}">
    <select name="student_id" required>
    <option value="">Select Student</option>`;
    students.forEach(s => html += `<option value="${s.student_id}">${s.full_name}</option>`);
    html += `</select><br>
    <input type="date" name="application_date" required><br>
    <button type="submit">Submit Application</button></form>`;
    res.send(html);
  });
});

app.post('/scholarships/apply/:id', (req, res) => {
  const scholarship_id = req.params.id;
  const { student_id, application_date } = req.body;
  db.query(`INSERT INTO scholarship_applications (student_id, scholarship_id, application_date)
            VALUES (?, ?, ?)`, [student_id, scholarship_id, application_date],
            (err) => {
              if (err) return res.status(500).send('Error applying for scholarship.');
              res.redirect('/scholarships');
            });
});

// ---------------- Loans & Repayment Routes ----------------

// Helper: compute monthly installment (simple annuity formula)
function monthlyInstallment(principal, annualRatePercent, months) {
  const r = (annualRatePercent / 100) / 12; // monthly rate
  if (r === 0) return (principal / months).toFixed(2);
  const numerator = r * Math.pow(1 + r, months);
  const denominator = Math.pow(1 + r, months) - 1;
  return (principal * (numerator / denominator)).toFixed(2);
}

// View all loan requests (admin view)
app.get('/loans', (req, res) => {
  db.query(`SELECT l.*, s.full_name 
            FROM loans l JOIN students s ON l.student_id = s.student_id
            ORDER BY l.created_at DESC`, (err, results) => {
    if (err) return res.status(500).send('Error fetching loans.');
    let html = `<h1>Loans</h1><a href="/loans/new">Request Loan</a><table border="1">
      <tr><th>Student</th><th>Amount</th><th>Rate</th><th>Months</th><th>Status</th><th>Actions</th></tr>`;
    results.forEach(l => {
      html += `<tr>
        <td>${l.full_name}</td>
        <td>R ${Number(l.loan_amount).toFixed(2)}</td>
        <td>${l.interest_rate}%</td>
        <td>${l.repayment_months}</td>
        <td>${l.status}</td>
        <td>
          ${l.status === 'pending' ? `<form method="POST" action="/loans/approve/${l.loan_id}" style="display:inline;">
              <button type="submit">Approve</button>
            </form>
            <form method="POST" action="/loans/reject/${l.loan_id}" style="display:inline;">
              <button type="submit">Reject</button>
            </form>` : ''}
          ${l.status === 'approved' ? `<a href="/loans/${l.loan_id}/schedule">View Schedule</a>` : ''}
        </td>
      </tr>`;
    });
    html += `</table>`;
    res.send(html);
  });
});

// Loan request form
app.get('/loans/new', (req, res) => {
  db.query('SELECT * FROM students', (err, students) => {
    if (err) return res.status(500).send('Error fetching students.');
    let html = `<h1>Request Loan</h1>
    <form method="POST" action="/loans/new">
      <select name="student_id" required>
        <option value="">Select Student</option>`;
    students.forEach(s => html += `<option value="${s.student_id}">${s.full_name}</option>`);
    html += `</select><br>
      <input name="loan_amount" type="number" step="0.01" placeholder="Loan Amount" required><br>
      <input name="interest_rate" type="number" step="0.01" placeholder="Annual Interest Rate (%)" required><br>
      <input name="repayment_months" type="number" placeholder="Repayment Months" required><br>
      <input type="date" name="start_date" required><br>
      <button type="submit">Request Loan</button>
    </form>`;
    res.send(html);
  });
});

app.post('/loans/new', (req, res) => {
  const { student_id, loan_amount, interest_rate, repayment_months, start_date } = req.body;
  const sql = `INSERT INTO loans (student_id, loan_amount, interest_rate, repayment_months, start_date)
               VALUES (?, ?, ?, ?, ?)`;
  db.query(sql, [student_id, loan_amount, interest_rate, repayment_months, start_date], (err) => {
    if (err) return res.status(500).send('Error requesting loan.');
    res.redirect('/loans');
  });
});

// Approve loan (admin)
app.post('/loans/approve/:id', (req, res) => {
  const id = req.params.id;
  // set approved and optionally set start_date = today if not set
  db.query('UPDATE loans SET status = "approved" WHERE loan_id = ?', [id], (err) => {
    if (err) return res.status(500).send('Error approving loan.');
    res.redirect('/loans');
  });
});

// Reject loan (admin)
app.post('/loans/reject/:id', (req, res) => {
  const id = req.params.id;
  db.query('UPDATE loans SET status = "rejected" WHERE loan_id = ?', [id], (err) => {
    if (err) return res.status(500).send('Error rejecting loan.');
    res.redirect('/loans');
  });
});

// View repayment schedule for an approved loan
app.get('/loans/:id/schedule', (req, res) => {
  const id = req.params.id;
  db.query('SELECT l.*, s.full_name FROM loans l JOIN students s ON l.student_id = s.student_id WHERE l.loan_id = ?', [id], (err, rows) => {
    if (err || rows.length === 0) return res.status(404).send('Loan not found.');
    const loan = rows[0];
    const monthly = monthlyInstallment(Number(loan.loan_amount), Number(loan.interest_rate), Number(loan.repayment_months));
    let html = `<h1>Repayment Schedule for ${loan.full_name}</h1>
      <p>Principal: R${Number(loan.loan_amount).toFixed(2)}</p>
      <p>Interest Rate (annual): ${loan.interest_rate}%</p>
      <p>Term: ${loan.repayment_months} months</p>
      <p>Monthly installment: R${monthly}</p>
      <a href="/loans">Back</a>`;
    res.send(html);
  });
});

// Mark loan as repaid (admin)
app.post('/loans/:id/mark-repaid', (req, res) => {
  const id = req.params.id;
  db.query('UPDATE loans SET status = "repaid" WHERE loan_id = ?', [id], (err) => {
    if (err) return res.status(500).send('Error marking loan repaid.');
    res.redirect('/loans');
  });
});

// ---------------- Financial Aid Applications ----------------

// View all financial aid applications (admin)
app.get('/aid-applications', (req, res) => {
  db.query(`SELECT a.*, s.full_name 
            FROM financial_aid_applications a
            JOIN students s ON a.student_id = s.student_id
            ORDER BY a.application_date DESC`, (err, results) => {
    if (err) return res.status(500).send('Error fetching applications.');
    let html = `<h1>Financial Aid Applications</h1>
      <a href="/aid-applications/new">Apply for Aid</a>
      <table border="1"><tr><th>Student</th><th>Type</th><th>Requested</th><th>Date</th><th>Status</th><th>Actions</th></tr>`;
    results.forEach(a => {
      html += `<tr>
        <td>${a.full_name}</td>
        <td>${a.aid_type}</td>
        <td>R ${Number(a.requested_amount).toFixed(2)}</td>
        <td>${a.application_date}</td>
        <td>${a.status}</td>
        <td>
          ${a.status === 'pending' ? `<form method="POST" action="/aid-applications/approve/${a.aid_id}" style="display:inline;">
              <button type="submit">Approve</button>
            </form>
            <form method="POST" action="/aid-applications/reject/${a.aid_id}" style="display:inline;">
              <button type="submit">Reject</button>
            </form>` : ''}
        </td>
      </tr>`;
    });
    html += `</table>`;
    res.send(html);
  });
});

// Apply for aid (student)
app.get('/aid-applications/new', (req, res) => {
  db.query('SELECT * FROM students', (err, students) => {
    if (err) return res.status(500).send('Error fetching students.');
    let html = `<h1>Apply for Financial Aid</h1>
      <form method="POST" action="/aid-applications/new">
        <select name="student_id" required>
          <option value="">Select Student</option>`;
    students.forEach(s => html += `<option value="${s.student_id}">${s.full_name}</option>`);
    html += `</select><br>
        <select name="aid_type" required>
          <option value="grant">Grant</option>
          <option value="bursary">Bursary</option>
          <option value="emergency_fund">Emergency Fund</option>
          <option value="other">Other</option>
        </select><br>
        <input name="requested_amount" type="number" step="0.01" placeholder="Requested Amount" required><br>
        <textarea name="reason" placeholder="Reason / details"></textarea><br>
        <input type="date" name="application_date" required><br>
        <button type="submit">Submit Application</button>
      </form>`;
    res.send(html);
  });
});

app.post('/aid-applications/new', (req, res) => {
  const { student_id, aid_type, requested_amount, reason, application_date } = req.body;
  const sql = `INSERT INTO financial_aid_applications (student_id, aid_type, requested_amount, reason, application_date)
               VALUES (?, ?, ?, ?, ?)`;
  db.query(sql, [student_id, aid_type, requested_amount, reason || null, application_date], (err) => {
    if (err) return res.status(500).send('Error submitting application.');
    res.redirect('/aid-applications');
  });
});

// Approve application (admin)
app.post('/aid-applications/approve/:id', (req, res) => {
  const id = req.params.id;
  // You can also set processed_by, processed_at if you track admin user
  db.query('UPDATE financial_aid_applications SET status = "approved", processed_at = NOW() WHERE aid_id = ?', [id], (err) => {
    if (err) return res.status(500).send('Error approving application.');
    res.redirect('/aid-applications');
  });
});

// Reject application (admin)
app.post('/aid-applications/reject/:id', (req, res) => {
  const id = req.params.id;
  db.query('UPDATE financial_aid_applications SET status = "rejected", processed_at = NOW() WHERE aid_id = ?', [id], (err) => {
    if (err) return res.status(500).send('Error rejecting application.');
    res.redirect('/aid-applications');
  });
});



app.use(express.static('public'));

// Start server
app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
